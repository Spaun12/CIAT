The exercises for this chapter only ask the user to save a 
single query named VendorsInCA. As a result, the VendorsInCA.sql
file is the only solution file for these exercises.