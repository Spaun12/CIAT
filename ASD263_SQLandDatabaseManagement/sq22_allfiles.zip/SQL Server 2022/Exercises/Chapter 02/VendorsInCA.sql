SELECT VendorName, VendorState 
FROM Vendors 
WHERE VendorState = 'CA'