For this chapter, many of the exercises don't ask the reader to save any files, so solutions aren't available for those exercises.

Here's how the solution files map to the exercises

Exercise  7: VendorsInCA.sql
Exercise 10: Chart1.sql
Exercise 12: Chart1.png (screen capture of chart)
Exercise 14: Chart2.sql
Exercise 16: Chart2.png (screen capture of chart)