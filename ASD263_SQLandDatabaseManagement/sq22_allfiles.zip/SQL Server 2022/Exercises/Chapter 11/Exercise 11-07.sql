SELECT name, collation_name 
FROM sys.databases
WHERE name = 'Membership';