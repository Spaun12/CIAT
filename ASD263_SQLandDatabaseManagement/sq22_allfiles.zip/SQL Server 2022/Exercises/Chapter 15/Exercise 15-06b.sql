USE AP;

SELECT *
FROM dbo.fnDateRange('10/10/22','10/20/22');
