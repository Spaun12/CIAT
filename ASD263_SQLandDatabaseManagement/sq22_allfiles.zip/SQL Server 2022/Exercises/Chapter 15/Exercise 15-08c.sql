USE AP;

UPDATE Invoices
SET PaymentTotal = 67.92, PaymentDate = '2023-02-23'
WHERE InvoiceID = 100;