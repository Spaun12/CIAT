USE AP;

SELECT *
INTO InvoiceCopy
FROM Invoices;

SELECT *
INTO VendorCopy
FROM Vendors;