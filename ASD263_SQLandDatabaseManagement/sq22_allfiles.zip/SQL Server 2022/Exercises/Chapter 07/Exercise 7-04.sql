USE AP;

UPDATE VendorCopy
SET DefaultAccountNo = 403
WHERE DefaultAccountNo = 400;
