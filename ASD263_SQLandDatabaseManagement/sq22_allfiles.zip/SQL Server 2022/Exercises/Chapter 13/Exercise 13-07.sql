SELECT *
FROM sys.foreign_keys;

-- The result set shows that there are 6 foreign keys defined in the AP database