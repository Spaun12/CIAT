USE AP;

EXEC spInvoiceReport;