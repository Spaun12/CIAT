USE AP;

UPDATE Invoices
SET PaymentTotal = 662, 
    PaymentDate = '2023-03-09'
WHERE InvoiceID = 98;
