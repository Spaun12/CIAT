USE AP;

SELECT * FROM dbo.fnTopVendorsDue(5000);