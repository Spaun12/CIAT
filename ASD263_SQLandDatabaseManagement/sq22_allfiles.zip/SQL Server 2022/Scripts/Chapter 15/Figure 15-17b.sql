USE AP;

DELETE Invoices
WHERE VendorID = 37;

SELECT * FROM InvoiceArchive;