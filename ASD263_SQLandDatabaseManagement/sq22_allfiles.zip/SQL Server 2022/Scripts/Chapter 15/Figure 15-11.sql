USE AP;

EXEC sp_HelpText spInvoiceReport;
