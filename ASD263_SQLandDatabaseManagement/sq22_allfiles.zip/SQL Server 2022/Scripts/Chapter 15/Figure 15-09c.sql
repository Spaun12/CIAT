USE AP;

-- view the data
SELECT * FROM InvoiceLineItems WHERE InvoiceID = 114;