USE AP;
GO

CREATE SCHEMA Accounting;