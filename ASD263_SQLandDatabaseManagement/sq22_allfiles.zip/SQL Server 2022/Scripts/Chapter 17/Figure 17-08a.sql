USE AP;

GRANT INSERT, UPDATE, DELETE
ON Invoices
TO SusanRoberts;