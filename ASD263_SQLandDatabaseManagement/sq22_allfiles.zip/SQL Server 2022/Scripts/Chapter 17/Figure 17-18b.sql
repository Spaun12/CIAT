/*
Log in using your Windows account
before running this script.
*/

USE AP;

DENY SELECT
ON GLAccounts
TO MartinRey;