USE AP;

ALTER ROLE db_owner ADD MEMBER JohnDoe;