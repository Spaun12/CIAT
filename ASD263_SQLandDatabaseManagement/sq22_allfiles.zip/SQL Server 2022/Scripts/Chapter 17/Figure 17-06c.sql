USE AP;

ALTER SCHEMA Accounting TRANSFER Marketing.Contacts;