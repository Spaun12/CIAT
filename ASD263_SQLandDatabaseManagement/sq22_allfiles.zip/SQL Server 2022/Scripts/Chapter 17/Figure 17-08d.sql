USE AP;

GRANT SELECT
ON Vendors (VendorName, VendorAddress1, VendorCity, VendorState, VendorZipCode)
TO JohnDoe, SusanRoberts;