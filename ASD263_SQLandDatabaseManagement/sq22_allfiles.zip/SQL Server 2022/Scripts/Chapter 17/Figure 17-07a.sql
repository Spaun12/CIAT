USE AP;

GRANT SELECT
ON Invoices
TO SusanRoberts;