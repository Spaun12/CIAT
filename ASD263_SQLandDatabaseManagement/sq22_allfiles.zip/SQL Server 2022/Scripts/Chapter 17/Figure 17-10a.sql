USE AP;

GRANT CREATE VIEW
TO JohnDoe, SusanRoberts;