USE AP;

GRANT UPDATE
ON SCHEMA :: Accounting
TO JohnDoe;