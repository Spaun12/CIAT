USE master;

GRANT ALTER ANY LOGIN
TO Consultant;