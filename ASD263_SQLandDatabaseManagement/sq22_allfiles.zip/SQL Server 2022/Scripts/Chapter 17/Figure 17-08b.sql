USE AP;

REVOKE DELETE
ON Invoices
FROM SusanRoberts;