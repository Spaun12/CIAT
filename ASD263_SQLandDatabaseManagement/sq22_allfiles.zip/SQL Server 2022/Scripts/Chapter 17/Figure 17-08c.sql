USE AP;

-- if spInvoiceReport doesn't exist, run "Figure 15-02a.sql" to create it.

GRANT EXECUTE
ON spInvoiceReport
TO JohnDoe, SusanRoberts;