USE AP;

REVOKE SELECT
ON Invoices
FROM SusanRoberts;