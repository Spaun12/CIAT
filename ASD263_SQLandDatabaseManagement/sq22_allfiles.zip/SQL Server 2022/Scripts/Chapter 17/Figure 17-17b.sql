USE AP;

EXEC sp_HelpRoleMember InvoiceEntry;