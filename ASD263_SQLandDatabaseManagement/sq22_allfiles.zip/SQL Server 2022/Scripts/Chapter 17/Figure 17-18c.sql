/*
Log in as MartinRey 
before running this script.
*/

USE AP;

SELECT * FROM GLAccounts;