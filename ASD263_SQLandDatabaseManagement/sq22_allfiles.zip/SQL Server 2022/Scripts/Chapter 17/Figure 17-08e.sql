USE AP;

GRANT REFERENCES
ON Accounting.Contacts
TO JohnDoe;