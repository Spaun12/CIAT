/*
   To allow you to run the scripts in the chapter successfully...
   
   * some of the statements that drop or alter users aren't included
   * some of the scripts that work with Windows Authentication aren't included
     since they work differently depending on each system.
   * some of the scripts have been modified slightly

*/