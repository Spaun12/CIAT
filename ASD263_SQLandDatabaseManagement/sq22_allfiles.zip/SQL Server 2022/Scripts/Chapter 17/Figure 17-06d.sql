USE AP;

DROP SCHEMA Marketing;