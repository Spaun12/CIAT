USE AP;

REVOKE UPDATE
ON SCHEMA :: Accounting
FROM JohnDoe;