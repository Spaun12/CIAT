USE AP;

EXEC sp_HelpRole;