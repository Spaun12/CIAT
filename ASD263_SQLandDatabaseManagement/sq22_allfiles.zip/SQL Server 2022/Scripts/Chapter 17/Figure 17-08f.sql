USE AP;

GRANT ALTER
ON Vendors
To JohnDoe;