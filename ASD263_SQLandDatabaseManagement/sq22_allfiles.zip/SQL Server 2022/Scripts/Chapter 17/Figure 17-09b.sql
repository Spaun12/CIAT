USE AP;

GRANT ALTER
ON SCHEMA :: Accounting
TO SusanRoberts;