USE AP;

-- The subquery
SELECT VendorID
FROM Vendors
WHERE VendorState = 'CA';
