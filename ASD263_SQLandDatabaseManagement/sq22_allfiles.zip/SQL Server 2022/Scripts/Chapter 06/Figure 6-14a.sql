USE Examples;

SELECT EmployeeID, LastName, FirstName, ManagerID
FROM Employees;
