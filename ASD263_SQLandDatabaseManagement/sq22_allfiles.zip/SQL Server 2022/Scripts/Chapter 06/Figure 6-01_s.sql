USE AP;

-- The subquery
SELECT AVG(InvoiceTotal)
FROM Invoices;
