USE AP;

SELECT * FROM VendorsMin
WHERE VendorState = 'CA'
ORDER BY VendorName;
