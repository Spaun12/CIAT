USE AP;

INSERT INTO IBM_Invoices (InvoiceNumber, InvoiceDate, InvoiceTotal)
VALUES ('RA23988', '2023-03-04', 417.34);
