USE Examples;

SELECT * FROM Investors;