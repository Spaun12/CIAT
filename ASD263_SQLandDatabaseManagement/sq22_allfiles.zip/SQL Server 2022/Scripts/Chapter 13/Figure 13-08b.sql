USE AP;

SELECT * FROM IBM_Invoices;