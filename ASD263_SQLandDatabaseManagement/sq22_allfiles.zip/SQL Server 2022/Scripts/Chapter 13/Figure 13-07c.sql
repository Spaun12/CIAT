USE AP;

UPDATE VendorPayment
SET PaymentTotal = 19351.18, PaymentDate = '2023-02-02'
WHERE VendorName = 'Malloy Lithographing Inc' AND InvoiceNumber = 'P-0608';
