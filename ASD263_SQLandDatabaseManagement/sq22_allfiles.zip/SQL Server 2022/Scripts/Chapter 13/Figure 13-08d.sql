USE AP;

DELETE FROM IBM_Invoices
WHERE InvoiceNumber = 'Q545443';
