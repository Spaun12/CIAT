USE Examples;

SELECT EmployeeID, LastName, FirstName, DeptNo
FROM Employees;