USE Examples;

SELECT CustomerFirst, CustomerLast
FROM Customers;