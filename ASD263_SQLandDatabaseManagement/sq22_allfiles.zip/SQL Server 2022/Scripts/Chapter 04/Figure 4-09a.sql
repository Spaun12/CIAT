USE Examples;

SELECT DeptName, DeptNo
FROM Departments;
