USE AP;
GO

SELECT *
FROM Invoices;

