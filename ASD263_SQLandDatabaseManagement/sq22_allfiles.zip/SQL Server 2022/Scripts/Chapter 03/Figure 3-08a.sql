USE AP;

SELECT VendorCity, VendorState
FROM Vendors
ORDER BY VendorCity;
