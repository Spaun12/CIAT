USE AP;

DELETE Invoices;