USE AP;

UPDATE Invoices
SET PaymentDate = '2023-03-21', 
    PaymentTotal = 19351.18
WHERE InvoiceNumber = '97/522';