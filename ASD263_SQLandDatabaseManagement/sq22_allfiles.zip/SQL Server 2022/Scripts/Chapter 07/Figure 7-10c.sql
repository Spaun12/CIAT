USE AP;

-- Clean up the InvoiceArchive table by deleting all rows from it
DELETE FROM InvoiceArchive;