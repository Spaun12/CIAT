USE AP;

DELETE Invoices
WHERE VendorID = 37;
