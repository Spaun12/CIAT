USE AP;

UPDATE Invoices
SET TermsID = 1
WHERE VendorID = 95;
