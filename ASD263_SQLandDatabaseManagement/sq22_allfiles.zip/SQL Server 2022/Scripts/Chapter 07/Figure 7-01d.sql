USE AP;

DROP TABLE InvoiceCopy;