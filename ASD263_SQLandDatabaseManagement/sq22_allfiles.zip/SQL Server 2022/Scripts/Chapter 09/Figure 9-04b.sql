USE Examples;

SELECT * FROM RealSample
WHERE R = 1;