USE Examples;

SELECT * FROM StringSample
ORDER BY ID;
