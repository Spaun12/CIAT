USE Examples;

SELECT * FROM RealSample