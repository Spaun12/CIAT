USE Examples;

SELECT * FROM DateSample
WHERE StartDate = '2022-10-28';
