USE Examples;

SELECT * FROM StringSample
ORDER BY CAST(ID AS int);
