USE Examples;

SELECT * FROM DateSample
WHERE StartDate >= '2022-10-28' AND StartDate < '2022-10-29';

