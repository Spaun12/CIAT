USE Payroll;

CREATE TABLE Employees
( 
  EmployeeID      INT            PRIMARY KEY,
  EmployeeName    VARCHAR(50)    COLLATE Latin1_General_100_CI_AS
);