CREATE DATABASE Test_AP
    ON PRIMARY (FILENAME = 'C:\Murach\SQL Server 2022\Databases\Test_AP.mdf')
    FOR ATTACH;
