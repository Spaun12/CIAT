USE New_AP;

CREATE TABLE Vendors
(VendorID       INT,
VendorName      VARCHAR(50));
