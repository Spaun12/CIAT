USE New_AP;

INSERT Invoices7
VALUES (1, 99, 100);
