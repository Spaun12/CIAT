SELECT * FROM sys.fn_helpcollations()
WHERE name LIKE 'Latin1_General_100%';