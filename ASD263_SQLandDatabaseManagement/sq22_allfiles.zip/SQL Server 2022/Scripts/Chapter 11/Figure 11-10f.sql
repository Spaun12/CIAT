USE New_AP;

SELECT current_value 
FROM sys.sequences
WHERE name = 'TestSequence3';

