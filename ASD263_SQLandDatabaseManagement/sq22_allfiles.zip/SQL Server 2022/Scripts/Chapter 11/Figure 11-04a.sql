USE New_AP;

CREATE INDEX IX_VendorID
    ON Invoices (VendorID);
