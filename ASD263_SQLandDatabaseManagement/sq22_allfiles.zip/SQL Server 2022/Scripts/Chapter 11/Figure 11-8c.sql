USE AP;

DROP TABLE New_AP.dbo.Vendors1;