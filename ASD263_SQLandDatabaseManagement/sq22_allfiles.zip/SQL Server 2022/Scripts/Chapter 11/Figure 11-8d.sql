USE master;

DROP DATABASE New_AP;