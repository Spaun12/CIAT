USE master;

-- if necessary, drop the AR database
DROP DATABASE IF EXISTS Payroll;

CREATE DATABASE Payroll COLLATE Latin1_General_100_CI_AS;