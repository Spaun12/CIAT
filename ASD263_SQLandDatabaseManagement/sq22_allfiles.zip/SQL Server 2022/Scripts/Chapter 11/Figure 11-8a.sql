USE New_AP;

DROP INDEX IX_Invoices ON Invoices;