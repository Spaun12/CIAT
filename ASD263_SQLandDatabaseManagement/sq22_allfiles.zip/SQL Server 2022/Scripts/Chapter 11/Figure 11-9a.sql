USE New_AP;

ALTER TABLE Vendors
ADD LastTranDate DATE NULL;
