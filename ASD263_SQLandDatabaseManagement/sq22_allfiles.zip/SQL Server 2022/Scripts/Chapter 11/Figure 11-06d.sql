USE New_AP;

INSERT Vendors1
VALUES ('Mc4559','Castle Printers, Inc.');
