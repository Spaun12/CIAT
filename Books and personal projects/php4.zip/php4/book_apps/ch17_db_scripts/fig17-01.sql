CREATE DATABASE IF NOT EXISTS my_guitar_shop3;

USE my_guitar_shop3;