<footer>
    <p class="copyright">
        &copy; <?php echo date('Y'); ?> My Guitar Shop, Inc.
    </p>
</footer>
</body>
</html>