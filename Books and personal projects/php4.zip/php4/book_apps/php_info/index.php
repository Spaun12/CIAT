<?php 
phpinfo();
?> 
