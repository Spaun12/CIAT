<!-- Step 4a: Display a form to enter order information -->
<form action="/Week3_MVC_Part2/?controller=add_order" method="post">
    <label for="customer_id">Customer ID:</label>
    <input type="number" name="customer_id" required><br>
    <label for="order_date">Order Date:</label>
    <input type="date" name="order_date" required><br>
    <label for="order_total">Order Total:</label>
    <input type="text" name="order_total" required><br>
    <input type="submit" value="Add Order">
</form>

