<?php
echo '<style>
    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
    }
    th, td {
        border: 1px solid #dddddd;
        padding: 8px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    td {
        word-wrap: break-word;
        max-width: 400px;
    }
</style>';

echo '<table>
    <thead>
        <tr>
            <th>ID</th> <!-- Added ID column header -->
            <th>Name</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>';
foreach ($customers as $customer) {
    echo '<tr>
        <td>' . htmlspecialchars($customer['id']) . '</td> <!-- Added ID column value -->
        <td>' . htmlspecialchars($customer['first_name'] . ' ' . $customer['last_name']) . '</td>
        <td>' . htmlspecialchars($customer['email']) . '</td>
    </tr>';
}
echo '</tbody>
</table>';
?>




