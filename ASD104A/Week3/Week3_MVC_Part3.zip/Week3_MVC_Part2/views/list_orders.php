<!-- Part3 3: Loop through the array of orders and display their information in a table -->
<style>
    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
        font-family: Arial, sans-serif;
    }
    th, td {
        border: 1px solid #dddddd;
        padding: 8px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    td {
        word-wrap: break-word;
        max-width: 400px;
    }
</style>';

<table>
    <thead>
        <tr>
            <th>Order ID</th>
            <th>Customer ID</th>
            <th>Order Date</th>
            <th>Order Total</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($orders as $order): ?>
            <tr>
                <td><?= htmlspecialchars($order['order_id']) ?></td>
                <td><?= htmlspecialchars($order['customer_id']) ?></td>
                <td><?= htmlspecialchars($order['order_date']) ?></td>
                <td>$<?= htmlspecialchars($order['order_total']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

