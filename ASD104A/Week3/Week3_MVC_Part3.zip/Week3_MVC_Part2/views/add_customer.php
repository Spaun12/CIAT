<?php
echo '<form action="/Week3_MVC_Part2/?controller=add_customer" method="post">
    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" id="first_name" required>
    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" id="last_name" required>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>
    <button type="submit">Add Customer</button>
</form>';
?>

