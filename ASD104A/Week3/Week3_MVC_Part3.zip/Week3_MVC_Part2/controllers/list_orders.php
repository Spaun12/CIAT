<?php
// Part 3 1a: Define a function to retrieve all orders
function list_orders() {
    global $connection;
    $query = "SELECT * FROM orders";
    $result = $connection->query($query);
    $orders = $result->fetch_all(MYSQLI_ASSOC);

    include 'views/list_orders.php'; // Part 3 1b: Load the view and pass the array of orders
}
?>
