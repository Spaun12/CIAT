<?php
// Part3 2a: Define a function to add an order
function add_order() {
    global $connection;
    $customer_id = $_POST['customer_id'];
    $order_date = $_POST['order_date'];
    $order_total = $_POST['order_total'];
    $query = "INSERT INTO orders (customer_id, order_date, order_total) VALUES ('$customer_id', '$order_date', '$order_total')";
    $connection->query($query);

    // Step 2b: Redirect to the list_orders page
    header('Location: /Week3_MVC_Part2/?controller=list_orders');

    return "Order added successfully!";
}
?>
