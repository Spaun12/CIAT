<?php
    // 3a-Define a function to add a customer
function add_customer() {
    global $connection;
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $query = "INSERT INTO customers (first_name, last_name, email) VALUES ('$first_name', '$last_name', '$email')";
    $connection->query($query);

    // 3b-Redirect to the list_customers page
    header('Location: /Week3_MVC_Part2/?controller=list_customers');
}
?>


