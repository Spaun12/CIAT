<?php
// Step 1a: Establish a database connection to the practice database on localhost
$connection = new mysqli('localhost', 'root', '', 'practice_db');
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Step 1b: Determine which controller to load based on the request URL
$controller = $_GET['controller'] ?? 'home';

// Step 1c: Call the appropriate method on the controller based on the request URL
if ($controller == 'list_customers') {
    echo '<a href="/Week3_MVC_Part2/">Home</a> | ';
    echo '<a href="/Week3_MVC_Part2/?controller=add_customer">Add Customer</a><br>';
    include 'controllers/list_customers.php';
    list_customers();
} elseif ($controller == 'add_customer') {
    echo '<a href="/Week3_MVC_Part2/">Home</a> | ';
    echo '<a href="/Week3_MVC_Part2/?controller=list_customers">List Customers</a><br>';
    include 'controllers/add_customer.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        add_customer();
    } else {
        include 'views/add_customer.php';
    }
} else {
    // Home page
    echo '<h1>practice_db MVC in Action</h1>'; // Title added here
    echo '<a href="/Week3_MVC_Part2/?controller=list_customers">List Customers</a> | ';
    echo '<a href="/Week3_MVC_Part2/?controller=add_customer">Add Customer</a>';
}
// Step 1d: Output the result of the method to the browser (handled within controllers)
?>
