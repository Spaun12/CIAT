<?php
    // 2a-Define a function to list customers
function list_customers() {
    global $connection;
    $query = "SELECT * FROM customers";
    $result = $connection->query($query);
    $customers = $result->fetch_all(MYSQLI_ASSOC);

    // 2b-Load the view and pass the customers data
    include 'views/list_customers.php';
}
?>




