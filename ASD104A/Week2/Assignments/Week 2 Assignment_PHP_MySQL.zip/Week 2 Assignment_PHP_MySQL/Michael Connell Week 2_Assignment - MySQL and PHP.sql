-- Michael Connell
-- 2023-08-12
-- This script is used to create the database and tables for the assignment.
-- It also populates the tables with data.

-- Creating a new database named another_test_database
CREATE DATABASE another_test_database;

-- Using the newly created database
USE another_test_database;

-- Creating the students table with necessary columns
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    student_firstname VARCHAR(50),
    student_lastname VARCHAR(50),
    address VARCHAR(100),
    city VARCHAR(50),
    state VARCHAR(2),
    zip VARCHAR(5),
    GPA DECIMAL(3,2),
    major VARCHAR(50)
);

-- Test data into the students table for testing queries but, I added much more in myPHPAdmin
INSERT INTO students (student_firstname, student_lastname, address, city, state, zip, GPA, major) VALUES
('John', 'Doe', '123 Main St', 'San Diego', 'CA', '90001', 3.0, 'ASD'),
('Jane', 'Smith', '456 Secondary St', 'Los Angeles', 'CA', '90002', 2.5, 'CSE');

-- Creating the courses table with necessary columns
CREATE TABLE courses (
    course_id VARCHAR(10) PRIMARY KEY,
    course_name VARCHAR(100),
    term VARCHAR(50),
    course_status VARCHAR(50) NULL
);

-- Test data into the courses table for testing queries but, I added much more in myPHPAdmin
INSERT INTO courses (course_id, course_name, term, course_status) VALUES
('ASD101', 'Introduction to ASD', 'Fall', 'Active'),
('CSE201', 'Introduction to CSE', 'Spring', NULL);

-- 1) Selecting all columns from the students table where the city is San Diego
SELECT * FROM students WHERE city = 'San Diego';

-- 2) Selecting specific columns and ordering them by course_name in descending order
SELECT course_name, term FROM courses ORDER BY course_name DESC;

-- 6) MySQL Query to Update "GPA" Column Where "student_id" is 12345
UPDATE students SET GPA = 3.5 WHERE student_id = 12345;

-- 9) MySQL Query to Select Rows from "courses" Where "course_status" is NULL
SELECT * FROM courses WHERE course_status IS NULL;

-- 10) MySQL Query to Select Rows from "courses" Where "course_id" starts with ASD
SELECT * FROM courses WHERE course_id LIKE 'ASD%';

