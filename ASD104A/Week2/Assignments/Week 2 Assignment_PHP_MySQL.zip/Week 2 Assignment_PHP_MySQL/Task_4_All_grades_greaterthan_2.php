<?php
// Task 4
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "another_test_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected successfully<br>";
}

// Query to select all students with GPA >= 2.0 and major starts with 'ASD'
$sql = "SELECT * FROM students WHERE GPA >= 2.0 AND major LIKE 'ASD%'";

// Print the query for debugging
echo "Running query: $sql<br>";

$result = $conn->query($sql);

// Check for SQL errors
if ($result === FALSE) {
    echo "Error executing query: " . $conn->error . "<br>";
}

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Name: " . $row["student_firstname"] . " " . $row["student_lastname"] . " - Major: " . $row["major"] . "<br>";
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();
?>



