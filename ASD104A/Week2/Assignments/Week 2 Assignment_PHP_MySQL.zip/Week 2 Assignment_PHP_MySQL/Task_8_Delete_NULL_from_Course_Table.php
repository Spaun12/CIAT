<?php
// Task 8
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "another_test_database";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "DELETE FROM courses WHERE course_name IS NULL";
if ($conn->query($sql) === TRUE) {
    echo "Records deleted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
