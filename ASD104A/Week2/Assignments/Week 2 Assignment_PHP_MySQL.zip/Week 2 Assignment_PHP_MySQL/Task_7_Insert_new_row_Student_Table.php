<?php
// Task 7
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "another_test_database";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "INSERT INTO students (student_firstname, student_lastname, address, city, state, zip) VALUES ('John', 'Doe', '123 Main St', 'Los Angeles', 'CA', '90001')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
