<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Debugging Challenge</title>
</head>
<body>
  <h1>Login Form</h1>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <!-- Create a form to accept username and password -->
    <label for="username">Username:</label>
    <input type="text" name="username" id="username">
    <br>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password">
    <br>
    <input type="submit" name="submit" value="Login">
  </form>
  <?php
    // Check if the request method is POST
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      // Syntax Correction: Use isset to safely get the value of 'username' and 'password'
      $username = isset($_POST['username']) ? $_POST['username'] : '';
      $password = isset($_POST['password']) ? $_POST['password'] : '';
      
      // Logical Correction: Check if both username and password are not empty
      if (empty($username) || empty($password)) {
        echo 'Please enter your username and password.';
      } else if ($username == 'admin' && $password == 'password123') {
        echo 'Login successful.';
      } else {
        echo 'Invalid username or password.';
      }
    }
  ?>
</body>
</html>


