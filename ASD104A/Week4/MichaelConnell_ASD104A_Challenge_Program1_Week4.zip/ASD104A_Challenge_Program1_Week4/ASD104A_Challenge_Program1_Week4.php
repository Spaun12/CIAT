<?php

$sum = 0; // Initialize sum variable to store the final result
$i = 0;   // Initialize counter variable to control the loop

do {
  $i++; // Increment counter by 1 (FIX: Added missing semicolon)
  switch ($i) { // Switch statement to evaluate the value of the counter
    case 1:
      $sum += 5; // Add 5 to sum if counter is 1
      break;
    case 2:
      $sum += 7; // Add 7 to sum if counter is 2 (FIX: Corrected operator from +== to +=)
      break;
    case 3:
      $sum += 3; // Add 3 to sum if counter is 3
      break;
    case 4:
      $sum += 2; // Add 2 to sum if counter is 4
      break;
    default:
      break; // Do nothing if counter is outside 1-4 (FIX: Added missing colon after default)
  }
} while ($i < 5); // Continue the loop while counter is less than 5 (FIX: Added parentheses around the condition)

echo "The sum is: " . $sum; // Print the final sum (FIX: Corrected variable name from $sun to $sum)

?>


