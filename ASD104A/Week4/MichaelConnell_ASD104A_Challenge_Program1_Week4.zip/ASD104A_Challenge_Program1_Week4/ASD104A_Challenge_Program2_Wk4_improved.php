<?php
// Sam as Program1 the original code for program2 seemed way too complicated for the task at hand.  I simplified it to the following:
$age = 20;
$price = 0;

// Define price tiers based on age making sure to match the index of each array
$childPrice = [3.5, 4.5, 6.5];
$adultPrice = [5.5, 7.5, 10.5];
$seniorPrice = [4.5, 6.5, 8.5];

// Determine the appropriate price based on age
for ($i = 0; $i < 3; $i++) {
  if ($age < 18) {
    $price += $childPrice[$i];
  } else if ($age >= 18 && $age < 60) {
    $price += $adultPrice[$i];
  } else {
    $price += $seniorPrice[$i];
  }
}

echo "The price is: $" . $price; // Print the final price

?>
