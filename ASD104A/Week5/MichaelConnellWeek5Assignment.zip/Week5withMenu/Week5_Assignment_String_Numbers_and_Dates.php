<!DOCTYPE html>
<html>
<head>
    <title>Week 5 - Assignment - String, Numbers and Dates</title>
    <meta name="author" content="Michael Connell">
    <meta name="date" content="2023-08-29">
    <script type="text/javascript">
        function adjustInputWidth(inputElement, maxWidth) {
            // Get the length of text entered and set a base size
            const textLength = inputElement.value.length;
            const baseSize = 10;
            // Calculate new size, but not exceeding maxWidth
            const newSize = Math.min(baseSize + textLength * 8, maxWidth);
            // Set the new width
            inputElement.style.width = newSize + 'px';
        }
    </script>
</head>
<body>

    <?php
    // Initialize $task with a default value
    $task = null;

    function displayMenu() {
        echo "<h1>Main Menu</h1>";
        echo "<ul>";
        for ($i = 1; $i <= 10; $i++) {
            echo "<li><a href='?task=task$i'>Task $i</a></li>";
        }
        echo "</ul>";
    }
    
    function capitalizeSentences($string) {
        // Split the string into sentences based on full stops
        $sentences = explode('. ', $string);
        
        // Capitalize the first letter of each sentence
        $sentences = array_map('ucfirst', $sentences);
        
        // Join the sentences back together
        return implode('. ', $sentences);
    }    

    if (isset($_GET['task'])) {
        $task = $_GET['task'];
        echo "<a href='?'>Home</a><br>";
        echo "<h2>Selected: $task</h2>"; // Displays which task is selected

        // Task specific code 1 through 10
        if ($task === 'task1' && $_SERVER["REQUEST_METHOD"] == "POST") {
            $string = $_POST["string"];
            $replacedString = str_ireplace("cat", "dog", $string);
            $finalString = capitalizeSentences($replacedString);
            echo "Replaced String: " . $finalString;
        }
        elseif ($task === 'task2') {
            $string = "It's a beautiful day!";
            echo "Escaped String: " . addslashes($string);
        }
        elseif ($task === 'task3' && $_SERVER["REQUEST_METHOD"] == "POST") {
            $string = $_POST["string"];
            echo "String Length: " . strlen($string);
        }
        elseif ($task === 'task4') {
            $string = "The quick brown fox jumps over the lazy dog.";
            $start = strpos($string, "lazy");
            echo "Substring: " . substr($string, $start);
        }
        elseif ($task === 'task5') {
            $string = "The quick brown fox jumps over the lazy dog.";
            echo "Position of 'lazy': " . strpos($string, "lazy");
        }
        elseif ($task === 'task6') {
            echo "Current Date: " . date("Y-m-d");
        }
        elseif ($task === 'task7') {
            echo "Current Date and Time: " . date("Y-m-d H:i:s");
        }
        elseif ($task === 'task8') {
            echo "Current Month and Year: " . date("F Y");
        }
        elseif ($task === 'task9' && $_SERVER["REQUEST_METHOD"] == "POST") {
            $date = $_POST["date"];
            $daysToAdd = $_POST["daysToAdd"];
            $newDate = date("Y-m-d", strtotime("$date +$daysToAdd days"));
            echo "New Date: " . $newDate;
        }
        elseif ($task === 'task10' && $_SERVER["REQUEST_METHOD"] == "POST") {
            $date1 = $_POST["date1"];
            $date2 = $_POST["date2"];
            $datetime1 = new DateTime($date1);
            $datetime2 = new DateTime($date2);
            $interval = $datetime1->diff($datetime2);
            echo "Difference: " . $interval->format("%y years, %m months, %d days");
        }
    } else {
        displayMenu();
    }
    ?>

    <!-- Forms for tasks -->
    <?php if ($task === 'task1'): ?>
        <form method="post" action="">
            <label for="string">Enter a string:</label>
            <input type="text" name="string" id="string" oninput="adjustInputWidth(this, 800)">
            <input type="submit" value="Submit">
        </form>
    <?php elseif ($task === 'task3'): ?>
        <form method="post" action="">
            <label for="string">Enter a string:</label>
            <input type="text" name="string" id="string" oninput="adjustInputWidth(this, 800)">
            <input type="submit" value="Submit">
        </form>
    <?php elseif ($task === 'task9'): ?>
        <form method="post" action="">
            <label for="date">Enter a date (YYYY-MM-DD):</label>
            <input type="text" name="date" id="date">
            <label for="daysToAdd">Enter the number of days to add:</label>
            <input type="number" name="daysToAdd" id="daysToAdd">
            <input type="submit" value="Submit">
        </form>
    <?php elseif ($task === 'task10'): ?>
        <form method="post" action="">
            <label for="date1">Enter the first date (YYYY-MM-DD):</label>
            <input type="text" name="date1" id="date1">
            <label for="date2">Enter the second date (YYYY-MM-DD):</label>
            <input type="text" name="date2" id="date2">
            <input type="submit" value="Submit">
        </form>
    <?php endif; ?>

</body>
</html>
